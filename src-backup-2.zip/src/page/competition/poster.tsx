import { Row, Col, Timeline } from 'antd';
import { Link } from 'react-router-dom';
import { Slide, Fade } from 'react-awesome-reveal';

import './poster.less';

import LogoHere from "../../assets/images/competitions-events/logo-here.png";
import IconTheme from "../../assets/images/competitions-events/theme.svg";
import IconTimeline from "../../assets/images/competitions-events/timeline.svg";
import IconPrize from "../../assets/images/competitions-events/total-prize.svg";
import IconContact from "../../assets/images/competitions-events/contact-person.svg";

import IconWhatsapp from "../../assets/images/competitions-events/whatsapp.png";
import IconLine from "../../assets/images/competitions-events/line.png";

export default function index() {
  return (
    <div>
      <div id="page-competition-poster">
        
        { /* ---------------------------------- ROW 1 --------------------------------- */}

        <Row align="middle" id="row1" className="mt-section mb-section">
          <Col className="col">
            <img src={LogoHere} className="mb-32"/>
            <div className="txt-headline purple mb-18">Poster</div>
            <div className="txt-body text-body">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</div>
            <Link to="#" className="btn-lime mt-48">Register</Link>
          </Col>
        </Row>
        
        { /* ---------------------------------- ROW 2 --------------------------------- */}

        <Row align="middle" id="row2" className="mt-section mb-section">
          <Col className="col">
            <Slide direction='left'>
              <img src={IconTheme} className="mb-32"/>
              <div className="txt-headline purple mb-18">Theme</div>
              <div className="txt-display-md linear-combine-txt text-center">Competition theme's here</div>
            </Slide>
          </Col>
        </Row>

        { /* ---------------------------------- ROW 3 --------------------------------- */}

        <Row align="middle" id="row3" className="mt-section mb-section">
          <Col className="col">
            <Slide direction='right'>
              <img src={IconTimeline} className="mb-32"/>
              <div className="txt-headline purple mb-48">Timeline</div>
              <Timeline
                mode="alternate"
                items={[
                  {
                    color: '#8F6DAC',
                    children: <div className="txt-body text-body"><span className='txt-body-bold linear-combine-txt'>00-00 Bulan 2023</span><br/>Open Registration</div>,

                  },
                  {
                    color: '#8F6DAC',
                    children: <div className="txt-body text-body"><span className='txt-body-bold linear-combine-txt'>00 Bulan 2023</span><br/>Submission</div>,

                  },
                  {
                    color: '#8F6DAC',
                    children: <div className="txt-body text-body"><span className='txt-body-bold linear-combine-txt'>00 Bulan 2023</span><br/>Finalist Announcement</div>,

                  },
                  {
                    color: '#8F6DAC',
                    children: <div className="txt-body text-body"><span className='txt-body-bold linear-combine-txt'>00 Bulan 2023</span><br/>Technical Meeting</div>,

                  },
                  {
                    color: '#8F6DAC',
                    children: <div className="txt-body text-body"><span className='txt-body-bold linear-combine-txt'>00 Bulan 2023</span><br/>Competition Day</div>,

                  },
                  {
                    color: '#8F6DAC',
                    children: <div className="txt-body text-body"><span className='txt-body-bold linear-combine-txt'>00 Bulan 2023</span><br/>Winner Announcement</div>,

                  },
                ]}
              />
            </Slide>
          </Col>
        </Row>


        { /* ---------------------------------- ROW 4 --------------------------------- */}

        <Row align="middle" id="row4" className="mt-section mb-section">
          <Col className="col">
            <Slide direction='left'>
              <img src={IconPrize} className="mb-32"/>
              <div className="txt-headline purple mb-18">Total Prize</div>
              <div className="txt-display-md linear-combine-txt text-center">USD 1000</div>
            </Slide>
          </Col>
        </Row>

        { /* ---------------------------------- ROW 5 --------------------------------- */}

        <Fade cascade damping={0.2}>
          <Row align="middle" id="row5" className="mt-section mb-section">
            <Col className="col">
              <img src={IconContact} className="mb-18"/>
              <div className="txt-headline purple">Contact Person</div>
            </Col>
          </Row>
        </Fade>

        { /* ---------------------------------- ROW 6 --------------------------------- */}
        
        <Row gutter={48} id="row6" className="mt-section mb-section">
          <Col xs={{ span: 24 }} md={{ span: 12 }} className="row6-col1">
            <Slide direction='right'>
              <div className='outer-card mb-24'>
                <div className="txt-headline lime mb-32">Full name here...</div>
                <Row className="glass-effect inner-card">
                  <Col xs={{ span: 24 }} md={{ span: 12}}>
                    <div className="flex-card mb-18">
                      <img src={IconWhatsapp} />
                      <div className="txt-body text-body ml-18">@yourusername</div>
                    </div>
                    <div className="flex-card">
                    <img src={IconLine} />
                      <div className="txt-body text-body ml-18">0899-9999-9999</div>
                    </div>
                  </Col>
                </Row>
              </div>
            </Slide>
          </Col>
          <Col xs={{ span: 24 }} md={{ span: 12 }} className="row6-col2">
            <Slide direction='left'>
              <div className='outer-card mb-24'>
                <div className="txt-headline amber mb-32">Full name here...</div>
                <Row className="glass-effect inner-card">
                  <Col xs={{ span: 24 }} md={{ span: 12}}>
                    <div className="flex-card mb-18">
                      <img src={IconWhatsapp} />
                      <div className="txt-body text-body ml-18">@yourusername</div>
                    </div>
                    <div className="flex-card">
                    <img src={IconLine} />
                      <div className="txt-body text-body ml-18">0899-9999-9999</div>
                    </div>
                  </Col>
                </Row>
              </div>
            </Slide>
          </Col>
        </Row>

      </div>
    </div>
  )
}
