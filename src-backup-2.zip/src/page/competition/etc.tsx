
export default function index() {
  return (
    <div>Upcoming Page</div>
  )
}
